
import jQuery from 'jquery'

(function ($) {
	$(document).on('ready', function () {
		alert('Backend, editado para docker x2!');
	})
})(jQuery)
