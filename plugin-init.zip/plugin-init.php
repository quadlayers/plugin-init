<?php

/**
 * Plugin Name:             Plugin Init
 * Plugin URI:              https://quadlayers.com/portfolio/plugin-init
 * Description:             Plugin Init description
 * Version:                 1.0.0
 * Text Domain:             plugin-init
 * Author:                  QuadLayers
 * Author URI:              https://quadlayers.com
 * License:                 GPLv3
 * Domain Path:             /languages
 * Request at least:        4.7.0
 * Tested up to:            6.1
 * Requires PHP:            5.6
 * WC requires at least:    4.0
 * WC tested up to:         7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


/**
*   Definition globals variables
*/

define( 'QLXXX_PLUGIN_NAME', 'Plugin Init' );
define( 'QLXXX_PLUGIN_VERSION', '1.0.0' );
define( 'QLXXX_PLUGIN_FILE', __FILE__ );
define( 'QLXXX_PLUGIN_DIR', __DIR__ . DIRECTORY_SEPARATOR );
define( 'QLXXX_DOMAIN', 'qlxxx' );
define( 'QLXXX_PREFIX', QLXXX_DOMAIN );
define( 'QLXXX_WORDPRESS_URL', 'https://wordpress.org/plugins/plugin-init/' );
define( 'QLXXX_REVIEW_URL', 'https://wordpress.org/support/plugin/plugin-init/reviews/?filter=5#new-post' );
define( 'QLXXX_DEMO_URL', 'https://quadlayers.com/demo/plugin-init/?utm_source=qlxxx_admin' );
define( 'QLXXX_PURCHASE_URL', 'https://quadlayers.com/portfolio/plugin-init/?utm_source=qlxxx_admin' );
define( 'QLXXX_SUPPORT_URL', 'https://quadlayers.com/account/support/?utm_source=qlxxx_admin' );
define( 'QLXXX_DOCUMENTATION_URL', 'https://quadlayers.com/documentation/plugin-init/?utm_source=qlxxx_admin' );
define( 'QLXXX_DOCUMENTATION_API_URL', 'https://quadlayers.com/documentation/plugin-init/api/?utm_source=qlxxx_admin' );
define( 'QLXXX_DOCUMENTATION_ACCOUNT_URL', 'https://quadlayers.com/documentation/plugin-init/account/?utm_source=qlxxx_admin' );
define( 'QLXXX_GROUP_URL', 'https://www.facebook.com/groups/quadlayers' );
define( 'QLXXX_DEVELOPER', false );
define( 'QLXXX_PREMIUM_SELL_URL', 'https://quadlayers.com/plugin-init-pro' );

/**
 * Load composer autoload
 */
require_once __DIR__ . '/vendor/autoload.php';
/**
 * Load vendor_packages packages
 */
require_once __DIR__ . '/vendor_packages/wp-i18n-map.php';
require_once __DIR__ . '/vendor_packages/wp-dashboard-widget-news.php';
require_once __DIR__ . '/vendor_packages/wp-plugin-table-links.php';
require_once __DIR__ . '/vendor_packages/wp-notice-plugin-required.php';
require_once __DIR__ . '/vendor_packages/wp-notice-plugin-promote.php';
/**
 * Load plugin classes
 */
require_once __DIR__ . '/lib/class-plugin.php';
/**
 * On plugin activation
 */
register_activation_hook(
	__FILE__,
	function() {
		do_action( 'qlxxx_activation' );
	}
);
/**
 * On plugin deactivation
 */
register_deactivation_hook(
	__FILE__,
	function() {
		do_action( 'qlxxx_deactivation' );
	}
);
