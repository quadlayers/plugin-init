﻿=== Plugin Init ===
Contributors: quadlayers
Donate link: https://quadlayers.com/
Tags: wordpress, woocommerce
Requires at least: 4.7
Requires PHP: 5.6
Tested up to: 6.1
Stable tag: 1.0.0
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html
