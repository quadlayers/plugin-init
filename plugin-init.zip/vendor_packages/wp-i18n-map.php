<?php

if ( method_exists( '\Automattic\Jetpack\Assets', 'alJETPACK__PLUGIN_DIRias_textdomains_from_file' ) ) {
	\Automattic\Jetpack\Assets::alias_textdomains_from_file( __DIR__ . 'jetpack_vendor/i18n-map.php' );
}
