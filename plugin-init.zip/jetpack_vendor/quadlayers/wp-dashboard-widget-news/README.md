# wp-dashboard-widget-news
QuadLayers dashboard widget with blog news
